<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title>Signin To WAYforward</title>
    <!-- Bootstrap core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/css/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="asset/css/social-buttons.css" rel="stylesheet" />
    

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">
      <h2 style="color:#fff; text-align: center; font-family: greetings"> signin to WAYforward</h2>
    <fieldset class="scheduler-border">
    <legend class="scheduler-border"><img src="asset/img/logo.png" alt="Mountains" style="color:#808080; text-align: center;"></legend>
      <form class="form-signin" method="post" action="#">
        <h2 class="form-signin-heading" style="color:#fff; text-align: center; font-family: greetings"><i class="fa fa-key"></i> Please sign in</h2>
        <label for="inputEmail" class="sr-only">Email address</label>
        <i class="fa fa-envelope" style="color:#fff;"></i><input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
        <br />
        <label for="inputPassword" class="sr-only">Password</label>
        <span class="block input-icon input-icon-right">
        <i class="fa fa-lock" style="color:#fff;"></i><input type="password" name="password" name="email" id="inputPassword" class="form-control" placeholder="Password" required>
      </span>
        <div class="checkbox">
          <label style="color:#fff;">
            <input type="checkbox" value="remember-me"> Remember me
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit"><i class="fa fa-sign-in"></i>  Sign in</button>
         <br />
        <a href="sign_up.php"><i class="fa fa-users"></i> Sign up</a>  <a href="sign_up.php"><i class="fa fa-lock"></i> Forget password</a> 
        <br /><br />
        <div class="text-center">
                                <a class="btn btn-social-icon btn-facebook" href="#"><i class="fa fa-facebook"></i></a>
                                <a class="btn btn-social-icon btn-instagram" href="#"><i class="fa fa-instagram"></i></a>
                                <a class="btn btn-social-icon btn-linkedin" href="#"><i class="fa fa-linkedin"></i></a>
                                <a class="btn btn-social-icon btn-twitter" href="#"><i class="fa fa-twitter"></i></a>
                            </div>
    </fieldset>
    </div> <!-- /container -->
       <?php include_once 'footer.php'; ?>
  </body>
</html>
